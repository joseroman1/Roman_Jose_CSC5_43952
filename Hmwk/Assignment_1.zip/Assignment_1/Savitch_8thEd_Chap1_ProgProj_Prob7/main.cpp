/* 
 * File:   main.cpp
 * Author: Jose Roman
 *Created on March 4, 2015, 9:40 AM
 *       Purpose: Homework Assignment
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants 

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Output of Large CS letters.
    cout<<"****************************************\n";
    cout<<"        C C C         S S S S      !!   \n";
    cout<<"      C       C      S       S     !!   \n";
    cout<<"     C              S              !!   \n";
    cout<<"    C                S             !!   \n";
    cout<<"    C                 S S S S      !!   \n";
    cout<<"    C                        S     !!   \n";
    cout<<"     C                        S    !!   \n";
    cout<<"      C       C     S        S          \n";
    cout<<"        C C C        S S S S       00   \n";
    cout<<"                                        \n";
    cout<<"****************************************\n";
    cout<<"   Computer Science is Cool Stuff!!!    \n";
  

    //Exit right stage!

    return 0;
}