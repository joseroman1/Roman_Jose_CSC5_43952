/* 
 * File:   main.cpp
 * Author: Jose Roman
 * Created on February 23, 2015, 9:55 AM
 *     Purpose:   Input/Process/Output and 
 *                   Flowchart!!1
 */

//System Libraries
#include <iostream>//I/O Library
using namespace std;//I/O Library under std namespace

//User Libraries
 
// Global Constant 

//Function Prototypes\

//Execution Begins Here!!!
int main(int argc, char** argv) {
    //Declare Variables 
    //Inputs:
    //  Pay Rate = payRate $'s/hr
    //  Hours Worked = hrsWrkd hrs
    //Output:
    //   Gross Pay Check Amount = payChk $'s
    float payRate, hrsWrkd, payChk;
    //Prompt the user for inputs
    cout<<"This program calculates your Gross Paycheck"<<endl;
    cout<<"Input you Pay Rate as $xx.xx, provide the x's. "<<endl;
    cin>>payRate;
    cout<<"Input your Hours Worked this pay period."<<endl;
    cout<<"Format xxx.x, provide the x's"<<endl;
    cin>>hrsWrkd;
    //Calculate the paycheck
    payChk=payRate*hrsWrkd;
    //Output the results
    cout<<"$"<<payChk<<" = $"<<payRate<<"/hr * "<<hrsWrkd<<"(hrs)"<<endl;
    

    
    return 0;
}

